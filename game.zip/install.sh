#!/bin/bash

menu_option_one() {
echo -e "\033[32m UPGRADE SISTEM.... \033[0m"
sleep 1
echo -e "\033[31m Connecting To cloud.maourafavpn.my.id...\033[0m\033[32m[STABLE]\033[0m"
sleep 1
echo -e "\033[31m Connecting To cloud.maourafavpn.my.id...\033[0m\033[32m[STABLE]\033[0m"
sleep 1
echo -e "\033[31m Connecting To cloud.maourafavpn.my.id...\033[0m\033[32m[\033[31mBAD REQUEST\033[0m]\033[0m"
sleep 1
echo -e "\033[31m Connecting To cloud.maourafavpn.my.id...\033[0m\033[32m[STABLE]\033[0m"
sleep 1
echo -e "\033[31m Connecting To cloud.maourafavpn.my.id...\033[0m\033[32m[STABLE]\033[0m"
sleep 1
echo -e "\033[31m Connecting To cloud.maourafavpn.my.id...\033[0m\033[32m[STABLE]\033[0m"
sleep 1
echo -e "\033[31m Connecting To cloud.maourafavpn.my.id...\033[0m\033[32m[STABLE]\033[0m"
sleep 1
echo -e "\033[31m Connecting To cloud.maourafavpn.my.id...\033[0m\033[32m[ \033[31mBAD REQUEST\033[0m ]\033[0m"
sleep 1
apt update -y
clear
apt upgrade -y
clear
echo -e "\033[32m Upgrade selesai, Tekan Enter lalu install data nomor 2 :)\033[0m"
}

menu_option_two() {
echo -e "\033[32m Installing Game Data...Check For Connection\033[0m"
echo -e "\033[32m Installing Game Data...Using Default Protocol\033[0m"
echo -e "\033[32m Installing Game Data...\033[0m"
sleep 3
pkg update -y
clear
pkg upgrade -y
clear
pkg install clang ncurses git make -y
clear
pkg install ncurses -y
clear
pkg install libsdl2-dev libsdl2-mixer-dev -y
pkg in repo x-11 -y
clear
pkg install sdl2 -y
pkg install sdl2-mixer -y
clear
echo -e "\033[32m Install virus eh maksudku data selesai 😅. silahkan enter lalu run game :3\033[0m"
}

menu_3() {
echo -e "\033[32m MENJALANKAN VIRU- EH MAKSUDNYA GAME....:)\033[0m"
chmod +x game
sleep 3
./game
}

press_enter() {
  echo ""
  echo -n "     Press Enter to continue "
  read
  clear
}

incorrect_selection() {
  echo "Incorrect selection! Try again."
}

until [ "$selection" = "0" ]; do
  clear
  echo ""
  echo "        1  -  Upgrade Sistem Dulu :)"
  echo "        2  -  Install Data Game :3"
  echo "        3  -  RUN GAME 😋"
  echo "        0  -  Exit"
  echo ""
  echo -n "  Enter selection: "
  read selection
  echo ""
  case $selection in
    1 ) clear ; menu_option_one ; press_enter ;;
    2 ) clear ; menu_option_two ; press_enter ;;
    3 ) clear ; menu_3 ; press_enter ;;
    0 ) clear ; exit ;;
    * ) clear ; incorrect_selection ; press_enter ;;
  esac
done

